using GroceryStoreAPI.Controllers;
using GroceryStoreAPI.Models;
using Newtonsoft.Json.Linq;
using System;
using Xunit;

namespace UnitTestGroceryStoreAPI
{
    public class GroceryStoreUT
    {
        CustomerRepository crp = new CustomerRepository();
        OrdersRepository ord = new OrdersRepository();
        ProductRepository prd = new ProductRepository();

        [Fact]
        public void APIListAllCustomers()
        {
            int listCount = crp.GetFullCustomersData().Count;
            Assert.True(listCount > 0);
        }

        [Fact]
        public void APIReturnCustomers()
        {
            string Name = crp.GetCustomers(1).Name;
            Assert.True(Name=="Bob");
        }

        [Fact]
        public void APIListAllOrders()
        {
            int listCount = ord.GetAllOrdersData().Count;
            Assert.True(listCount > 0);
        }

        [Fact]
        public void APIReturnOrders()
        {
            Orders orders = ord.GetOrders(1);
            Assert.True(orders.Id == 1);
        }

        [Fact]
        public void APIListAllProducts()
        {
            int listCount = prd.GetAllProductsData().Count;
            Assert.True(listCount > 0);
        }

        [Fact]
        public void APIReturnProduct()
        {
            Products products = prd.GetProducts(1);
            Assert.True(products.Id == 1);
        }

        [Fact]
        public void APISaveCustomer()
        {
            var test = "{'id': 5,'name': 'Post1 Test'}";
            var rs = JObject.Parse(test);
            if (crp.GetCustomers(Convert.ToInt32(rs["id"].ToString())) == null)
            {
                crp.Save(test);
                Assert.True(true);
            }
        }

        [Fact]
        public void APISaveCustomerValidate()
        {
            int updatecount = crp.GetFullCustomersData().Count;
            Assert.True(updatecount == 5);
        }

        [Fact]
        public void APISaveProduct()
        {
            var test = "{'id': 5,'description': 'Test apple','price': 0.15}";
            var rs = JObject.Parse(test);
            if (prd.GetProducts( Convert.ToInt32(rs["id"].ToString())) == null)
            {
                prd.SaveProduct(test);
                Assert.True(true);
            }
            
        }
        [Fact]
        public void APISaveProductValidate()
        {
            int updatecount = prd.GetAllProductsData().Count;
            Assert.True(updatecount == 5);
        }

    }
}

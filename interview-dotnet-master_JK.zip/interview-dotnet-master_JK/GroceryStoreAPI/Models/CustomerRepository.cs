﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//using GroceryStoreAPI.App_Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;

namespace GroceryStoreAPI.Models
{
    public class CustomerRepository : ICustomerRepository
    {
        private List<Customers> _customersList;
        private string path = @"C:\Learning\interview-dotnet-master\GroceryStoreAPI\App_Data\database.json";
        
        public CustomerRepository()
        {
            //trial 2
            var customerJson = System.IO.File.ReadAllText(path);
            JObject jobj = JObject.Parse(customerJson);
            _customersList = JsonConvert.DeserializeObject<List<Customers>>(jobj["Customers"].ToString());

            //trial 1 - errors 
            ///_customersList = context.Customers.ToList();

        }

        public List<Orders> GetAllOrdersData()
        {
            throw new NotImplementedException();
        }

        public Customers GetCustomers(int Id)
        {
            return _customersList.FirstOrDefault(e => e.Id == Id);
        }

        public List<Customers> GetFullCustomersData()
        {
            return _customersList;
        }

        public Orders GetOrders(int Id)
        {
            throw new NotImplementedException();
        }

        public void Save(string stringJsonValue)
        {
            JObject cusobj = JObject.Parse(System.IO.File.ReadAllText(path));
            JArray Addincomingdata = cusobj["Customers"].Value<JArray>();
            var data = JObject.Parse(stringJsonValue);
            Addincomingdata.Add(data);
            cusobj["Customers"] = Addincomingdata;
            string newJsonResult = JsonConvert.SerializeObject(cusobj,Formatting.Indented);
            File.WriteAllText(path, newJsonResult);
        }
    }
}

﻿using GroceryStoreAPI.App_Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GroceryStoreAPI.Models
{
    public abstract class MainRepository
    {
        protected readonly DBContextFile _context;

        public MainRepository(DBContextFile context)
        {
            _context = context;
        }
    }
}

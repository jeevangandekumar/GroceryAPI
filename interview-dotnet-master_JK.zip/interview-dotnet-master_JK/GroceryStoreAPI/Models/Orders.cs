﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GroceryStoreAPI.Models
{
    public class Orders
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public IList<Items> Items { get; set; } = new List<Items>();
        
       // public Customers Customers { get; set; }
    }

    public class Items
    {
        public int ProductId { get; set; }
        public double Quantity { get; set; }
    }
}

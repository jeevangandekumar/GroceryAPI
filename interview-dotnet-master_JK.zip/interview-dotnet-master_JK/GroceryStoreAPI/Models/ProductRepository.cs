﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GroceryStoreAPI.Models
{
    public class ProductRepository : IProductRepository
    {
        private List<Products> _productsList;
        private string path = @"C:\Learning\interview-dotnet-master\GroceryStoreAPI\App_Data\database.json";
        public ProductRepository()
        {
            var productJson = System.IO.File.ReadAllText(path);
            JObject jobj = JObject.Parse(productJson);
            _productsList = JsonConvert.DeserializeObject<List<Products>>(jobj["Products"].ToString());
        }
        public List<Products> GetAllProductsData()
        {
            return _productsList;
        }

        public Products GetProducts(int Id)
        {
            return _productsList.FirstOrDefault(p => p.Id == Id);
        }

        public void SaveProduct(string stringJsonValue)
        {
            JObject productobj = JObject.Parse(System.IO.File.ReadAllText(path));
            JArray Addincomingdata = productobj["Products"].Value<JArray>();
            var data = JObject.Parse(stringJsonValue);
            Addincomingdata.Add(data);
            productobj["Products"] = Addincomingdata;
            string newJsonResult = JsonConvert.SerializeObject(productobj, Formatting.Indented);
            File.WriteAllText(path, newJsonResult);

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GroceryStoreAPI.Models
{
    public interface IProductRepository
    {
        Products GetProducts(int Id);
        List<Products> GetAllProductsData();
        void SaveProduct(string stringJsonValue);
    }
}

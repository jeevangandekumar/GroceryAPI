﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GroceryStoreAPI.Models
{
    public interface IOrdersRepository
    {
        Orders GetOrders(int Id);
        List<Orders> GetAllOrdersData();
    }
}

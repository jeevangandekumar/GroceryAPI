﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GroceryStoreAPI.Models
{
    public class OrdersRepository : IOrdersRepository
    {
        private List<Orders> _ordersList;

        public OrdersRepository()
        {
            var orderJson = System.IO.File.ReadAllText(@"C:\Learning\interview-dotnet-master\GroceryStoreAPI\App_Data\database.json");
            JObject jobj = JObject.Parse(orderJson);
            _ordersList = JsonConvert.DeserializeObject<List<Orders>>(jobj["Orders"].ToString());
        }
        public List<Orders> GetAllOrdersData()
        {
            return _ordersList;
        }

        public Orders GetOrders(int Id)
        {
            return _ordersList.FirstOrDefault(o => o.Id == Id);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GroceryStoreAPI.Models
{
    public interface ICustomerRepository
    {
        Customers GetCustomers(int Id);
        List<Customers> GetFullCustomersData();
        void Save(string stringJsonValue);
    }
}

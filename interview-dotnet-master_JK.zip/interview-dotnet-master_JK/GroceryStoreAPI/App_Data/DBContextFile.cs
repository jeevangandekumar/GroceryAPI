﻿using GroceryStoreAPI.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GroceryStoreAPI.App_Data
{
    public class DBContextFile:DbContext
    {
        public DbSet<Customers> Customers { get; set; }
        public DbSet<Orders> Orders { get; set; }
        public DbSet<Products> Products { get; set; }

        public DBContextFile(DbContextOptions<DBContextFile> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            var customerJson = System.IO.File.ReadAllText(@"C:\Learning\interview-dotnet-master\GroceryStoreAPI\App_Data\database.json");
            JObject jobj = JObject.Parse(customerJson);
            var customerdata = JsonConvert.DeserializeObject<List<Customers>>(jobj["Customers"].ToString());
            var ordersdata = JsonConvert.DeserializeObject<List<Customers>>(jobj["Orders"].ToString());
            var productdata = JsonConvert.DeserializeObject<List<Customers>>(jobj["Products"].ToString());

            base.OnModelCreating(builder);

            builder.Entity<Customers>().ToTable("Customers");
            builder.Entity<Customers>().HasKey(c => c.Id);
            builder.Entity<Customers>().HasKey(c => c.Name);
            builder.Entity<Customers>().HasMany(o => o.Orders).WithOne(c => c.Customers).HasForeignKey(c => c.CustomerId);
            builder.Entity<Customers>().HasData(customerdata);

            builder.Entity<Products>().ToTable("Products");
            builder.Entity<Products>().HasKey(p => p.Id);
            builder.Entity<Products>().HasKey(p => p.Description);
            builder.Entity<Products>().HasKey(c => c.Price);            
            builder.Entity<Products>().HasData(productdata);



        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GroceryStoreAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GroceryStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private IOrdersRepository _orderRepository;
        public OrdersController(IOrdersRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public JsonResult GetOrderDetails(int id)
        {
            Orders orders = _orderRepository.GetOrders(id);
            return new JsonResult(orders);
        }

        // GET api/values
        [HttpGet]
        public ActionResult<List<Orders>> GetAllOrders()
        {
            return _orderRepository.GetAllOrdersData();
        }
    }
}
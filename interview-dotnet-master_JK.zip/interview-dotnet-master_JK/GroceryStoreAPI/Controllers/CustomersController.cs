﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GroceryStoreAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace GroceryStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        // C:\Learning\interview-dotnet-master\GroceryStoreAPI\database.json
        //string dbJson = JsonConvert.DeserializeObject<>()

        private ICustomerRepository _customerRepository;

        public CustomersController(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public JsonResult GetCustomer(int id)
        {
            Customers customer = _customerRepository.GetCustomers(id);
            return  new JsonResult(customer) ;
        }

        // GET api/values
        [HttpGet]
        public ActionResult<List<Customers>> GetFullCustomers()
        {
            return _customerRepository.GetFullCustomersData();
        }

        //// GET api/values
        //[HttpGet]
        //public ActionResult<IEnumerable<string>> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        //// GET api/values/5
        //[HttpGet("{id}")]
        //public ActionResult<string> Get(int id)
        //{
        //    return "value";
        //}

        //sample string '{"Id": 2,"Name": "TestDev"}'
        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
            _customerRepository.Save(value);
        }

        //// PUT api/values/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/values/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}

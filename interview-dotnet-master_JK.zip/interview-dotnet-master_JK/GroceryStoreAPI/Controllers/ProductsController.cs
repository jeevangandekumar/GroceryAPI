﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GroceryStoreAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GroceryStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private IProductRepository _productRepository;
        public ProductsController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public JsonResult GetProduct(int id)
        {
            Products product = _productRepository.GetProducts(id);
            return new JsonResult(product);
        }

        // GET api/values
        [HttpGet]
        public ActionResult<List<Products>> GetFullProductsData()
        {
            return _productRepository.GetAllProductsData();
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
            _productRepository.SaveProduct(value);
        }
    }
}